# 🚢 Kapal Selam Website

Project website sederhana bertema kapal selam untuk latihan GitHub.

## Fitur
- Desain tema laut
- HTML, CSS, JavaScript dasar
- Tombol interaktif

## Cara Menjalankan
1. Download atau clone repo ini
2. Buka index.html di browser

## Author
Project latihan GitHub
