function showMessage() {
    alert("Menyelam ke dalam laut! 🌊");
}
